<!DOCTYPE html>
<html>
<head>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<style>
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}

.input-field {
  width: 100%;
  padding: 10px;
  padding-left: 30px;
  font-size: 15px;
  outline: none;
}

.icon {
  padding: 15px;
  background: #185dcc;
  color: white;
  min-width: 50px;
  text-align: center;
} 

body{
  background-color: #e5e5e5; 
  background-position: center; 
  background-repeat: no-repeat; 
  background-size: cover;
 }
 p{
  font-size:20px;
  color:#2d2d2d;
 }
</style>
</head>
<body>
<center><h2><u>Login Form</u></h2></center>
<form  method="POST" action="record_check.php" name="form"  enctype="multipart/form-data" style="max-width:500px;margin:auto">
<br><br><br>
<p>Email:</p>
<div class="input-container">
<i class="fa fa-envelope icon"></i>
<input class="input-field" type="text" autocomplete="off" name="email" placeholder="Enter E-Mail" required><br><br>
</div>
<br>
<p>Password:</p>
<div class="input-container">
<i class="fa fa-lock icon"></i>
<input class="input-field" type="password" autocomplete="off" name="password" placeholder="Enter Password" required><br><br>
</div>

<input style="float:right;width: 90px; background-color:#185dcc;color: white " type="submit" name="save" value="Login" class="btn"><br><br>

</form>

</body>
</html>