<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}
.icon{
 background-color:#7a875f;
}
.btn {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 16px;
  font-size: 16px;
  cursor: pointer;
}
.input-field {
  width:10%;
  font-size: 15px;
  outline: none;
}
.btn:hover {
  background-color: RoyalBlue;
}
.button {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 15px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  <!--margin: 4px 2px;-->
  cursor: pointer;
}
</style>
</head>
<body style="background-image:url('bg1.jpg');background-position: center;background-repeat:no-repeat;background-size:cover">
<?php
include "db_con.php";
include "header.php";
 session_start();
// echo site_url;
 if(isset($_POST['save'])){
	 
// $conn=mysqli_connect("localhost","root","","prac");
 /*print_r($_FILES); 
      $name     = $_FILES['myFile']['name'];
	  $type     = $_FILES['myFile']['type'];
      $location = $_FILES['myFile']['tmp_namee'];
 
 */
 $email=$_SESSION['email'];
 $sql = mysqli_query($conn,"INSERT INTO user_data(EMail,Image) VALUE ('$email','".$_FILES["myFile"]["name"]."')");
 $target_dir = "uploads/";
 $target_file = $target_dir . basename($_FILES["myFile"]["name"]);
/* if (move_uploaded_file($_FILES["myFile"]["tmp_name"], $target_file)) {
        echo "The file has been uploaded <br>";
 }*/
  if (move_uploaded_file($_FILES["myFile"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["myFile"]["name"]). " has been uploaded.<br><br>";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
//mysqli_close($conn);
 }
?>
<?php
if(isset($_SESSION['email'])){
?>
<?php   
 echo "<center>
		 <h1>Welcome ".$_SESSION['name']."
		 </h1>
		 </center>"; 
 
?>
    <br><br><br><br><br>
	
	<form  method="POST" action="" name="form"  enctype="multipart/form-data">
	<div class="input-container">
	  <input type="file" name="myFile"><br><br>
	  </div>
	  <br>
	  <input type="submit" name="save" class="button btn" style="background-color: #7a875f">
	</form>
	<br>
    <br><br><br>
<?php	
}
else{
     header("location:index.html");
}
 
?>
</body>
</html>