<html>
<head>
<style>
 body{
  background-color:#e0e1e2; 
  background-position: center; 
  background-repeat: no-repeat; 
  background-size: cover;
 }
</style>
</head>
<body>
<?php 
include "db_con.php";
include "header.php";
echo "<br>";
session_start();
$select_img = mysqli_query($conn,"select * from user_data where EMail='".$_SESSION['email']."'");
while($fet_select_img = mysqli_fetch_array($select_img)){
$path = site_url."uploads/";?>
    <img src="<?php echo $path.$fet_select_img['Image'];?>" height='150' width='200'>
    <br><br>
 <?php } 
 ?>
 </body>
 </html>
	