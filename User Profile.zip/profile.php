<?php
error_reporting(0);
$x=0;
if($x=isset($_POST['save'])){
 session_start();
 include "db_con.php";
 $sql = mysqli_query($conn,"UPDATE user_info SET Profile='".$_FILES['pic']['name']."' WHERE EMail='".$_SESSION['email']."'");
 $dire="profilepic/";
 $dire_file=$dire.basename($_FILES["pic"]["name"]);
if(!move_uploaded_file($_FILES["pic"]["tmp_name"], $dire_file)){
 echo "Sorry, there was an error uploading your file.";
    }
/*if($sql){
 echo "Uploaded Successfully";
}
else{
 echo "Error!";
}*/
mysqli_close($conn);
}
if(!$x){
session_start();}
include "../db_con.php";
include "header.php";
echo "<br>";
$select_img = mysqli_query($conn,"select * from user_info where EMail='".$_SESSION['email']."'");
$fet_select_img = mysqli_fetch_array($select_img);
$path = site_url."profilepic/";
?>
 <table cellpadding="10">
  <tr> 
   <td rowspan="0" colspan="2"><img src="<?php echo $path.$fet_select_img['Profile'];?>" height='150' width='200'><td>
  </tr>
  <tr> 
   <td>Name:<?php echo $_SESSION['name'];?></td>
  </tr>
  <tr> 
   <td>E-Mail:<?php echo $_SESSION['email'];?></td>
  </tr>
  <tr> 
   <td>Gender:<?php echo $_SESSION['gen'];?></td>
  </tr>
  <tr> 
   <td>Date of Birth:<?php echo $_SESSION['birth'];?></td>
  </tr>
 </table>
 <br>
<form method="POST" action="" name="myform" enctype="multipart/form-data">
<p>Change Profile Pic</p>
 <input type="file" name="pic">
 <br>
 <input type="submit" name="save">
</form>
<br>