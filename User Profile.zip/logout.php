<?php

session_start();
if(isset($_GET['logout'])){
        session_destroy();
		header("location:index.html");
   }
   else{
    header("location:index.html");
   }

?>