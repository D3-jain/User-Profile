<?php 
$conn = mysqli_connect("localhost","root","","prac");

define("site_url","http://".$_SERVER['HTTP_HOST']."/Dheeraj/Prac/");
?>
