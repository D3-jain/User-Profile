<?php
 session_start();
 if(isset($_POST['save'])){
	 
 $conn=mysqli_connect("localhost","root","","prac");
 
 $sql = mysqli_query($conn,"SELECT * FROM user_info WHERE EMail='".$_POST['email']."' and Password='".$_POST['password']."'");
 $var=mysqli_fetch_assoc($sql);
 if($var){
	 $_SESSION['email']=$_POST['email'];
	 $_SESSION['name']=$var['Name'];
	 $_SESSION['ppic']=$var['Profile'];
	 $_SESSION['birth']=$var['DateofBirth'];
	 $_SESSION['gen']=$var['Gender'];
 header('location: welcome.php');
}else{
	echo "email id and password is incorrected";
}
 }
?>