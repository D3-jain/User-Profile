<!DOCTYPE html>
<?php 
if(isset($_POST['save'])){
	include "db_con.php";
	//print_r($_POST); exit;
	//exit;
	//$sql = mysqli_query($conn,"INSERT INTO user_info([Name],[E-Mail],[Password],[Gender],[Date of Birth]) VALUE('".$_POST['Name']."','".$_POST['email']."','".$_POST['password']."','".$_POST['gender']."','".$_POST['dob']."')");
 //$con=mysqli_connect("localhost","root","","prac");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
//echo "INSERT INTO user_info(Name,EMail,Password,Gender,DateofBirth) VALUE('".$_POST['Name']."','".$_POST['email']."','".$_POST['password']."','".$_POST['gender']."','".$_POST['dob']."')"; exit;
// Perform queries 

$sql = mysqli_query($conn,"INSERT INTO user_info(Name,EMail,Password,Gender,DateofBirth,Profile) VALUE('".$_POST['Name']."','".$_POST['email']."','".$_POST['password']."','".$_POST['gender']."','".$_POST['dob']."','".$_FILES['pic']['name']."')");
$dire="profilepic/";
$dire_file=$dire.basename($_FILES["pic"]["name"]);
if(move_uploaded_file($_FILES["pic"]["tmp_name"], $dire_file)){
 echo "The file ". basename( $_FILES["pic"]["name"]). " has been uploaded.<br><br>";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
//mysqli_query($con,"INSERT INTO user_info (Name) 
//VALUES ('".$_POST['email']."','""')");
if($sql){
 header("location:index.html");
}
else{
 echo "Error!";
}

mysqli_close($conn);
}
?>
<html>
<head>
<title>Registration Page</title>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.icon {
  padding: 15px;
  background: #636d54;
  color: white;
  min-width: 50px;
  text-align: center;
} 
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}
.input-field {
  width: 100%;
  padding: 10px;
  padding-left: 10px;
  font-size: 15px;
  outline: none;
}
 p{
  font-size:20px;
  color:#2d2d2d;
 }
 body{
  background-image: url("baw.jpg"); 
  background-position: center; 
  background-repeat: no-repeat; 
  background-size: cover;
 }
</style>
<script>
function myfun(){
 var a  = document.getElementById("chname").value;
 var m  = document.getElementById("chmail").value;	
 var p  = document.getElementById("chpass").value;
 var cp = document.getElementById("ch_c_pass").value;
 if(p.length>=8)
 {
	 if(cp!=p)
	 {
		 alert("Password does not match");
		 return false;
	 }
 }
 else
 {
	 alert("Password should contain at least 8 characters");
	 return false;
 }
 if((/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/).test(m)==false)
	 {
                alert('Invalid Email Address');
                return false;
     }
 if((/^[A-Za-z]+$/).test(a)==false)
{
alert("Please Enter Only Characters");
return false;
}
}
</script>
</head>
<body>
<center><h2><u>Registration Page</u></h2></center>
<form onsubmit="return myfun()" method="POST" action="" name="myform" enctype="multipart/form-data" style="max-width:300px;margin:auto">
<br>
<p>Name:</p>
<div class="input-container">
<i class="fa fa-user icon"></i>
<input class="input-field" type="text" name="Name" id="chname" autocomplete="off" placeholder="Enter Name" required><br><br>
</div>
<p>Email:</p>
<div class="input-container">
<i class="fa fa-envelope icon"></i>
<input type="text" name="email" id="chmail" autocomplete="off" placeholder="Enter E-Mail" required><br><br>
</div>
<p>Password:</p>
<div class="input-container">
<i class="fa fa-lock icon"></i>
<input type="password" name="password" id="chpass" placeholder="Enter Password" required><br><br>
</div>
<p>Confirm Password:</p>
<div class="input-container">
<i class="fa fa-lock icon"></i>
<input type="password" name="c_password" id="ch_c_pass" placeholder="Re-Enter Password" required><br><br>
</div>
<p>Gender:</p>
<div class="input-container">
<input type="radio" name="gender" value="male" checked> <p>Male</p>     
<input type="radio" name="gender" value="female"> <p>Female</p>
<input type="radio" name="gender" value="other"> <p>Other</p><br>
</div>
<p>Date of Birth:</p>
<div class="input-container">
<i class="fa fa-calendar icon"></i>
<input type="date" name="dob"><br><br>
</div>
<p>Profile Pic:</p>
 <input type="file" name="pic">
<br>
<input style="float:right;color:white;background-color:#636d54" class="btn" type="submit" name="save" value="Register"><br>
</form>
</body>
</html>